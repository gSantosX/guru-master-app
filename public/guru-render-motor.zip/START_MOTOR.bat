@echo off
title Guru Master - Motor de Renderizacao Local
color 0b
echo ========================================================
echo        GURU MASTER - MOTOR DE RENDERIZACAO
echo ========================================================
echo.
echo Inicializando conexao entre o Site e a sua Maquina...

:: Verifica se Python esta instalado
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [AVISO] Python nao foi encontrado no sistema.
    echo Por favor, instale o Python a partir da Microsoft Store ou python.org
    echo E MARQUE A CAIXINHA "Add Python to PATH" durante a instalacao!
    pause
    exit /b
)

:: Verifica FFmpeg (basico)
ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [AVISO] FFmpeg nao encontrado no PATH.
    echo O motor tentara instalar o FFmpeg usando o Winget...
    winget install ffmpeg --silent
)

echo [OK] Ambiente checado. Instalando/Atualizando dependencias (isso pode demorar 1 min)...
pip install -r backend/requirements.txt --disable-pip-version-check -q

echo.
echo ========================================================
echo [OK] MOTOR PRONTO E CONECTADO! STATUS: ONLINE (Porta 5000)
echo ========================================================
echo V0.1 Auto-Flow Engine
echo.
echo [ATENCAO] Mantenha esta janela aberta enquanto renderiza.
echo Pode voltar para o site do Guru Master e clicar em "Gerar Video".
echo.

python backend/api.py
pause
